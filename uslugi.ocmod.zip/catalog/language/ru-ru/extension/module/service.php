<?php
// Heading
$_['heading_title'] = 'Услуги';

// Text
$_['text_price'] = 'Цена:';
